from django.shortcuts import render
from django.http import Http404
import csv
import json
import os
import logging
import pandas as pd
import plotly.graph_objs as go
import plotly.express as px
import plotly.io as pio
from django.shortcuts import render, Http404
import matplotlib.pyplot as plt
import io
from django.http import HttpResponse, Http404

# Configure logging
logger = logging.getLogger(__name__)
logging.basicConfig(level=logging.DEBUG)

def get_csv_path():
    return os.path.join(os.path.dirname(__file__), 'static', 'dump.csv')

def company_list(request):
    csv_path = get_csv_path()
    try:
        df = pd.read_csv(csv_path)
        if 'index_name' not in df.columns:
            raise ValueError("Column 'index_name' not found in CSV headers")
        companies = df['index_name'].dropna().tolist()
    except FileNotFoundError:
        raise Http404("CSV file not found")
    except ValueError as e:
        raise Http404(str(e))

    return render(request, 'company_list.html', {'companies': companies})

def company_data(request, company_name):
    csv_path = get_csv_path()
    company_data = []
    try:
        df = pd.read_csv(csv_path)
        if 'index_name' not in df.columns:
            raise ValueError("Column 'index_name' not found in CSV headers")
        company_data = df[df['index_name'] == company_name]
        if company_data.empty:
            raise ValueError(f"No data found for company: {company_name}")

        # Get chart type from request, default to 'bar'
        chart_type = request.GET.get('chart_type', 'bar')

        if chart_type == 'pie':
            fig = px.pie(company_data, names='index_date', values='closing_index_value', title=f'{company_name} Pie Chart')
        elif chart_type == 'scatter':
            fig = px.scatter(company_data, x='index_date', y='closing_index_value', title=f'{company_name} Scatter Plot')
        elif chart_type == 'histogram':
            fig = px.histogram(company_data, x='closing_index_value', title=f'{company_name} Histogram')
        else:
            fig = px.bar(company_data, x='index_date', y='closing_index_value', title=f'{company_name} Bar Chart')

        plotly_html = pio.to_html(fig, full_html=False)

    except FileNotFoundError:
        raise Http404("CSV file not found")
    except ValueError as e:
        raise Http404(str(e))

    return render(request, 'company_data.html', {'company_name': company_name, 'plotly_html': plotly_html})


def download_chart(request, company_name):
    if request.method == 'POST':
        csv_path = get_csv_path()
        try:
            df = pd.read_csv(csv_path)
            company_data = df[df['index_name'] == company_name]
            chart_type = request.POST.get('chart_type', 'bar')

            if chart_type == 'pie':
                fig = px.pie(company_data, names='index_date', values='closing_index_value', title=f'{company_name} Pie Chart')
            elif chart_type == 'scatter':
                fig = px.scatter(company_data, x='index_date', y='closing_index_value', title=f'{company_name} Scatter Plot')
            elif chart_type == 'histogram':
                fig = px.histogram(company_data, x='closing_index_value', title=f'{company_name} Histogram')
            else:
                fig = px.bar(company_data, x='index_date', y='closing_index_value', title=f'{company_name} Bar Chart')

            # Create a BytesIO object to save the image
            img_io = io.BytesIO()
            pio.write_image(fig, file=img_io, format='png')
            img_io.seek(0)

            # Create a downloadable response
            response = HttpResponse(img_io, content_type='image/png')
            response['Content-Disposition'] = f'attachment; filename="{company_name}_chart.png"'

            return response
        except FileNotFoundError:
            raise Http404("CSV file not found")
    else:
        raise Http404("Invalid request method")