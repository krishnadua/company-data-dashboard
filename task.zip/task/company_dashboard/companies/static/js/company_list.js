document.addEventListener('DOMContentLoaded', function() {
    const showSidebarBtn = document.getElementById('show-sidebar');
    const sidebar = document.querySelector('.sidebar');

    showSidebarBtn.addEventListener('click', function() {
        sidebar.classList.toggle('show');
    });
});