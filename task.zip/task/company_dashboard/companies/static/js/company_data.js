document.addEventListener('DOMContentLoaded', function() {
    const chartTypeSelect = document.getElementById('chart-type');
    const chartDiv = document.getElementById('chart');
    const downloadBtn = document.getElementById('download-btn');

    // Parse chart data and company name
    let chartData = JSON.parse('{{ plotly_data|escapejs }}'); // Ensure this is a valid JSON string
    let companyName = '{{ company_name|escapejs }}';
    let chartType = chartTypeSelect.value;

    // Function to render the chart based on selected type
    function renderChart() {
        let trace = [];
        if (chartType === 'pie') {
            trace = [{
                type: 'pie',
                labels: chartData.index_date,
                values: chartData.closing_index_value,
                textinfo: 'label+percent'
            }];
        } else if (chartType === 'scatter') {
            trace = [{
                type: 'scatter',
                mode: 'markers',
                x: chartData.index_date,
                y: chartData.closing_index_value,
                marker: { size: 12 }
            }];
        } else if (chartType === 'histogram') {
            trace = [{
                type: 'histogram',
                x: chartData.closing_index_value
            }];
        } else {
            trace = [{
                type: 'bar',
                x: chartData.index_date,
                y: chartData.closing_index_value
            }];
        }

        Plotly.newPlot(chartDiv, trace, { title: `Chart for ${companyName}` });
    }

    // Function to handle chart download
    function downloadChart() {
        Plotly.downloadImage(chartDiv, {
            format: 'png',
            width: 800,
            height: 600,
            filename: `chart_${companyName}_${chartType}`
        }).then(function(gd) {
            console.log('Image downloaded successfully');
        }).catch(function(error) {
            console.error('Error downloading image:', error);
        });
    }

    // Event listener for chart type change
    chartTypeSelect.addEventListener('change', function() {
        chartType = this.value;
        renderChart();
    });

    // Event listener for download button click
    downloadBtn.addEventListener('click', function() {
        downloadChart();
    });

    // Initial chart render
    renderChart();
});