from django.urls import path
from . import views
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
   path('', views.company_list, name='company_list'),
    # Use a regex pattern to match company names with spaces and special characters
    path('company_data/<str:company_name>/', views.company_data, name='company_data'),
     path('download_chart/<str:company_name>/', views.download_chart, name='download_chart'),
]

if settings.DEBUG:
    urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)